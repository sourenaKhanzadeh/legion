from a import *

print("Goodbye world!")